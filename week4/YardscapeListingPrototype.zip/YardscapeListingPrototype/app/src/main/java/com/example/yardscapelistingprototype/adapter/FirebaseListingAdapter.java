package com.example.yardscapelistingprototype.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.yardscapelistingprototype.Listing;
import com.example.yardscapelistingprototype.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

// Firebase version of the recycler adapter which fetches listings from a JSON file

public class FirebaseListingAdapter extends FirebaseRecyclerAdapter<Listing, FirebaseListingAdapter.listingViewholder> {

    public FirebaseListingAdapter(@NonNull FirebaseRecyclerOptions<Listing> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull listingViewholder holder, int position, @NonNull Listing model) {
        View view = holder.itemView;

        // Sets Textviews to proper Listing values
        holder.itemTitle.setText(model.getListing_title());
        holder.itemDesc.setText(model.getListing_description());
        holder.itemDate.setText(model.getListing_date());
        holder.itemTime.setText(model.getListing_time());


    }


    @NonNull
    @Override
    public listingViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);

        return new FirebaseListingAdapter.listingViewholder(view);
    }

    class listingViewholder extends RecyclerView.ViewHolder {
        TextView itemTitle, itemDesc, itemDate, itemTime;
        public listingViewholder(@NonNull View itemView) {
            super(itemView);

            itemTitle = itemView.findViewById(R.id.listing_title);
            itemDesc = itemView.findViewById(R.id.listing_desc);
            itemDate = itemView.findViewById(R.id.listing_date);
            itemTime = itemView.findViewById(R.id.listing_time);
        }
    }
}


